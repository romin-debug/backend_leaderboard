// credentials.js
const MONGODB = {
    user: "student",
    pw: "rominpatel2211",
}

const SESSION = {
    secret: "My super secret"
}

module.exports = {
    MONGODB: MONGODB,
    SESSION: SESSION
};
